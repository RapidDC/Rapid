exports.get_first = (lista) => {
    const list = [];

    for (let i of lista){
        list.push(i);
    }

    return list;
};